#!/bin/bash

BIN_PATH=`pwd`/bin

export LD_LIBRARY_PATH=$BIN_PATH

$BIN_PATH/zim